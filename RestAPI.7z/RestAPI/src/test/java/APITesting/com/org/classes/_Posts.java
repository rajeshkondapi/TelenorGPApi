package APITesting.com.org.classes;

public class _Posts {
	
	private String id;
	private String title;
	private String author;
	private info info;
	
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public info getInfo(){
		return info;
	}
	public void setInfo(info info){
		this.info = info;
	}
	

}
