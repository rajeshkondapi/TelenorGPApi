package DatabaseConnections;

public class LocalDBVariables {

	private int id;
	private String country;
	private String nam;
	private String abbr;
	private String are;
	private String largest_city ;
	private String capital;
	/**
	 * @return the id
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		
		this.country = country;
	}
	/**
	 * @return the nam
	 */
	public String getNam() {
		return nam;
	}
	/**
	 * @param nam the nam to set
	 */
	public void setNam(String nam) {
		this.nam = nam;
	}
	
	/**
	 * @param abbr the abbr to set
	 */
	public void setAbbr(String abbr) {
		
		this.abbr = abbr ;
	}
	/**
	 * @return the abbr
	 */
	public String getAbbr() {
		
		return this.abbr;
		
	}
	/**
	 * @return the are
	 */
	public String getAre() {
		
		return are;
		
	}
	/**
	 * @param are the are to set
	 */
	public void setAre(String are) {
		this.are = are;
	}
	/**
	 * @return the largest_city
	 */
	public String getLargest_city() {
		return largest_city;
	}
	/**
	 * @param largest_city the largest_city to set
	 */
	public void setLargest_city(String largest_city) {
		this.largest_city = largest_city;
	}
	/**
	 * @return the capital
	 */
	public String getCapital() {
		return capital;
	}
	/**
	 * @param capital the capital to set
	 */
	public void setCapital(String capital) {
		this.capital = capital;
	}
	

}
